Nyumba landlord app - interactive prototype

Open index.html in a browser (phone or computer). It is one self-contained file.
To host it free: upload index.html to a GitHub repository and turn on GitHub Pages.

Notes
- All tenants, phone numbers, payments and M-Pesa codes are SAMPLE data. Nothing is saved; a reload resets it.
- The intro video is a trimmed 8-second clip of someone else's footage (a Florida house).
  It is a placeholder. Replace it with your own footage before sharing the app publicly.
  intro-clip.mp4 is that same clip, kept here so you can see what to replace.
- To use your own clip: make a short, muted, portrait MP4, convert it to base64
  and paste it into the <video id="vid" src="data:video/mp4;base64,..."> tag in index.html.
- Reminders are text you copy and send yourself; the page cannot send SMS or take real M-Pesa payments.
