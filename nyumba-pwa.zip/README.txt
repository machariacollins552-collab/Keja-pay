Nyumba landlord app - installable web app (PWA)

FILES (all in one folder, upload all 7 together to the main folder of your GitHub repo):
  index.html            the app (intro video is inside this file)
  manifest.webmanifest  tells Android how to install it
  sw.js                 saves the app so it works offline
  icon-192.png, icon-512.png, icon-maskable-512.png, apple-touch-icon.png   app icons

PUT IT ONLINE (GitHub Pages)
1. Repo > Code tab > Add file > Upload files. Select all 7 files together. Commit changes.
2. Repo > Settings > Pages > Source: Deploy from a branch > main, / (root) > Save.
   (Free GitHub accounts need a PUBLIC repo for Pages.)
3. Wait about a minute, then open the address Pages shows. It must start with https.

INSTALL ON ANDROID
Open the address in Chrome. Tap the menu (three dots) > Install app (or Add to Home screen).
Open it once while online. After that it also opens without internet.

UPDATING LATER
When you upload a new index.html, also open sw.js and change the version name in sw.js (currently nyumba-v2) to nyumba-v3, then v4 and so on.
Otherwise phones may keep showing the old saved copy for a while.

NOTES
- All tenants, payments and M-Pesa codes are SAMPLE data. Nothing is saved; reload resets it.
- The intro video is a placeholder (someone else's Florida house footage). Replace with your own before making the site public.
- Reminders are text you copy and send yourself. The app cannot send SMS or take M-Pesa payments.
- Putting the files in the Claude artifact preview will NOT install or work offline; that only works from your own https address.
